# Khidmat.ai — Requirements Audit Report

## Summary

| Category | Met? | Score |
|---|---|---|
| Multilingual & Noisy Input | ✅ Full | 10/10 |
| Advanced Provider Matching | ⚠️ Partial | 7/10 |
| Skill & Job Complexity | ✅ Full | 9/10 |
| Scheduling Intelligence | ⚠️ Partial | 5/10 |
| Dynamic Pricing | ⚠️ Partial | 6/10 |
| Booking Simulation | ⚠️ Partial | 7/10 |
| Service Quality Loop | ⚠️ Partial | 6/10 |
| Dispute & Escalation | ✅ Good | 8/10 |
| Provider-Side Optimization | ❌ Missing | 3/10 |
| Robustness & Fallback | ✅ Good | 8/10 |

**Overall: 69/100** — Solid foundation, several gaps to close.

---

## 1. Multilingual & Noisy Input ✅ FULL

| Sub-requirement | Status | Evidence |
|---|---|---|
| Urdu / Roman Urdu / English | ✅ | Prompt explicitly instructs Gemini to handle all three |
| Code-switching ("Mujhe kal...") | ✅ | Same prompt coverage |
| Misspellings & slang | ✅ | LLM handles this naturally |
| Confidence score | ✅ | `confidence_score` (0.0–1.0) in schema |
| Clarification questions | ✅ | `clarification_needed` + `clarification_question` field, same language as user |

**No gaps.**

---

## 2. Advanced Provider Matching ⚠️ PARTIAL

Requirement says **at least 6 factors**. Current implementation:

| Factor | Status | Code Location |
|---|---|---|
| Distance / travel time | ✅ | `distanceScore = max(0, 30 - distance*2)` |
| Rating | ✅ | `(rating/5) * 25` |
| Reliability / on-time score | ✅ | `(reliabilityScore/100) * 20` |
| Cancellation rate | ✅ | Penalty `(cancellationRate/15)*15` |
| Capacity / availability | ✅ | `(availableCapacity/capacity)*10` |
| Budget sensitivity | ✅ | +10 pts if `budget_sensitivity=high` & `baseRate < 1000` |
| Review recency | ❌ Missing | Not in providers.json or scoring |
| Skill specialization | ❌ Missing | No specialization field in providers |
| User preference history | ❌ Missing | No user profile / history |
| Risk score | ❌ Missing | Not calculated |

**Has 6 factors ✅ (meets minimum), but missing 4 of the listed ones.**

---

## 3. Skill & Job Complexity ✅ GOOD

| Sub-requirement | Status | Evidence |
|---|---|---|
| basic / intermediate / complex classification | ✅ | `complexity` field in intent schema |
| Match to provider specialization | ⚠️ | Complexity affects pricing but NOT matching score |
| Complexity pricing multipliers | ✅ | 1.0x / 1.5x / 2.5x in pricingAgent |
| Experience / tools / certifications | ❌ Missing | Not in provider data |

**Gap:** Complexity is extracted but doesn't influence which provider is selected — only the price.

---

## 4. Scheduling Intelligence ⚠️ PARTIAL

| Sub-requirement | Status | Evidence |
|---|---|---|
| Prevent double booking | ✅ | `capacity <= jobsToday` check in bookingAgent |
| Travel-time buffer | ❌ Missing | Distance scored but no travel-time buffer in scheduling |
| Suggest alternate slots | ❌ Missing | Only returns current slot or error |
| Manage waitlists | ❌ Missing | No waitlist logic |
| Auto-reschedule on provider cancel | ❌ Missing | Only logs dispute, doesn't re-match |

**Significant gap.** Only double-booking check is present.

---

## 5. Dynamic Pricing ⚠️ PARTIAL

| Sub-requirement | Status | Evidence |
|---|---|---|
| Demand / surge conditions | ❌ Missing | Not implemented |
| Urgency premium | ✅ | +Rs. 500 for `urgency=high` |
| Distance cost | ✅ | Rs. 50/km after 5km threshold |
| Service complexity multiplier | ✅ | 1.0x / 1.5x / 2.5x |
| Provider base rate | ✅ | Uses `provider.baseRate` |
| Loyalty discount | ❌ Missing | No user history tracked |
| Breakdown shown | ✅ | Full breakdown returned in API + shown in app |
| Fairness to provider | ❌ Missing | No provider earnings visibility |
| Budget-sensitive alternative | ⚠️ | Budget sensitivity in matching (lower rate providers ranked higher) but no "alternative quote" offered |

---

## 6. Booking Simulation ⚠️ PARTIAL

| Sub-requirement | Status | Evidence |
|---|---|---|
| Booking confirmation | ✅ | `CONFIRMED` status, bookingId generated |
| Provider assignment | ✅ | Provider name, phone, photo stored |
| Calendar update | ❌ Missing | scheduledTime stored but no calendar integration |
| SMS / WhatsApp notification | ❌ Simulated only | Text message in response but no actual send |
| Receipt | ⚠️ | Price breakdown returned but no PDF/receipt format |
| Database update | ✅ | SQLite insert via sql.js |

---

## 7. Service Quality Loop ⚠️ PARTIAL

| Sub-requirement | Status | Evidence |
|---|---|---|
| En-route update | ✅ | `EN_ROUTE` status with "ETA 15 min" message |
| Service completion checklist | ⚠️ | "Verify checklist" message but no actual checklist |
| Photo / video evidence placeholder | ❌ Missing | Not implemented |
| Customer feedback / rating | ⚠️ | "Rate your experience" prompt but no actual rating system |
| Rating adjustment | ❌ Missing | Provider rating never updated after job |
| Future matching impact | ❌ Missing | No feedback loop to provider score |

---

## 8. Dispute & Escalation ✅ GOOD

| Sub-requirement | Status | Evidence |
|---|---|---|
| No-show handling | ✅ | PKR 500 credit + provider flag |
| Quality complaint | ✅ | 30% refund + senior supervisor |
| Price disagreement | ✅ | Amount held + human escalation |
| Refund simulation | ✅ | Mentioned in resolution text |
| Cancellation | ✅ | Booking status updated to DISPUTED |
| Overrun | ❌ Missing | Not handled |
| Blacklist | ❌ Missing | `providerPenalty=true` flagged but no actual blacklist |
| Human escalation | ✅ | "Support team contact in 2 hours" |

---

## 9. Provider-Side Optimization ❌ MISSING

| Sub-requirement | Status |
|---|---|
| Workload balancing | ❌ Missing |
| Fair earning opportunity | ❌ Missing |
| Demand forecasting | ❌ Missing |
| Recommended time slots | ❌ Missing |

**Largest gap.** There is no provider-facing dashboard or optimization logic at all.

---

## 10. Robustness & Fallback ✅ GOOD

| Sub-requirement | Status | Evidence |
|---|---|---|
| No provider available | ✅ | `NO_PROVIDERS` status returned |
| Low-confidence parsing | ✅ | `clarification_needed=true` triggers follow-up |
| API failure fallback | ✅ | QUOTA_EXCEEDED / MODEL_NOT_FOUND / INVALID_API_KEY error types |
| Payment failure | ⚠️ | No actual payment; booking always succeeds |
| User preference conflicts | ⚠️ | Budget sensitivity handled; other conflicts not |

---

## Priority Fixes to Close the Gaps

### 🔴 High Priority (affects scoring significantly)

1. **Provider specialization field** — Add `specializations: ["ac-repair", "electrical"]` to providers.json and factor it into matching score
2. **Complexity → Matching** — Boost providers whose specializations match the job complexity level
3. **Surge/demand pricing** — Add time-of-day and demand multiplier to pricingAgent
4. **Alternate slot suggestion** — When no provider is available, suggest next available time slot
5. **Rating update after feedback** — When a booking is COMPLETED, update provider reliability score

### 🟡 Medium Priority

6. **Review recency field** — Add `lastReviewDate` to providers and factor recency into score
7. **Loyalty discount** — Track booking count per user and apply discount after 3+ bookings
8. **Provider workload dashboard** — Add `/api/data/workload` endpoint showing provider utilization

### 🟢 Nice to Have

9. **Photo evidence placeholder** — Accept a photo URL on booking completion
10. **Waitlist logic** — When capacity is full, add user to waitlist and notify when slot opens
