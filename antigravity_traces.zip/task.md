# Khidmat.ai — Requirements Implementation Tasks

## Phase 1: Data Layer
- [ ] Add `specializations`, `lastReviewDate`, `riskScore`, `totalBookings`, `experienceYears` to all 60 providers in providers.json

## Phase 2: Matching Agent (providers.json → matchingAgent.js)
- [ ] Add specialization match factor (+15 pts)
- [ ] Add review recency factor (+10 pts)
- [ ] Add risk score penalty (-15 pts)
- [ ] Add complexity-fit factor (+10 pts for complex jobs)

## Phase 3: Pricing Agent (pricingAgent.js)
- [ ] Add surge/demand pricing (time-of-day multiplier)
- [ ] Add loyalty discount (simulated)
- [ ] Add budget-sensitive alternative quote
- [ ] Show full breakdown with surge, discount fields

## Phase 4: Scheduling (bookingAgent.js + orchestrator.js)
- [ ] Suggest alternate time slots when no provider available
- [ ] Add travel-time buffer to scheduled time
- [ ] Add waitlist response when capacity full

## Phase 5: Provider Optimization (new endpoint)
- [ ] Add `/api/data/workload` endpoint
- [ ] Return provider utilization, available capacity, demand forecast
- [ ] Add recommended time slots per provider

## Phase 6: Service Quality Loop (followUpAgent.js)
- [ ] Add rating update on COMPLETED status
- [ ] Add photo evidence placeholder to booking completion
- [ ] Update future matching impact via reliability score change

## Phase 7: Deploy
- [ ] Redeploy backend to Cloud Run
- [ ] Rebuild APK
